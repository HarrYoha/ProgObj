package pobj.pinboard.document;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class ClipGroup extends AbstractClip implements Composite {
	
	 private List<Clip> list=new ArrayList<>();
	 
	 
			
	private void ChangeGeometrie() {
		 double left,top,right,bottom;
		 double min=10000;
		 for(Clip c: list) {
			if(c.getTop()<min) {
				min=c.getTop();
			}
		}
		top=min;
		double mini=10000;
		for(Clip c: list) {
			if(c.getLeft()<mini) {
				mini=c.getLeft();
			}
		}
		left=mini;
		
		double max=0;
		for(Clip c: list) {
			if(c.getBottom()>max) {
				max=c.getBottom();
			}
		}
		bottom=max;
		
		double maxi=0;
		for(Clip c: list) {
			if(c.getRight()>maxi) {
				maxi=c.getRight();
			}
		}
		right=maxi;
		setGeometry(left, top, right, bottom);
	}
	
	@Override
	public void draw(GraphicsContext ctx) {
		for(Clip c:list) {
			c.draw(ctx);
		}
	}
	
	public void move(double x, double y) {
		for(Clip c:list ) {
			c.move(x, y);
		}
		super.move(x, y);
	}
	
	
	 
	@Override
	public Clip copy() {
		ClipGroup cg=new ClipGroup();
		for(Clip c: list) {
			cg.addClip(c.copy());
		}
		return cg;
	}

	@Override
	public List<Clip> getClips() {
		return list;
	}

	@Override
	public void addClip(Clip toAdd) {
		list.add(toAdd);
		ChangeGeometrie();
		
	}

	@Override
	public void removeClip(Clip toRemove) {
		list.remove(toRemove);
		ChangeGeometrie();
		
	}
	
	 
	
}
