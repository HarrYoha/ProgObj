package pobj.pinboard.test;

import pobj.pinboard.document.*;
import pobj.pinboard.editor.EditorWindow;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class TestDocument extends javafx.application.Application {
	@Override
	public void start(javafx.stage.Stage stage) throws Exception {

		// code originale
		
		  Canvas canvas = new Canvas(800, 600); VBox vbox = new VBox();
		  vbox.getChildren().add(canvas); stage.setScene(new javafx.scene.Scene(vbox));
		  Board board = new Board(); board.addClip(new ClipRect(100, 100, 300, 200,
		  Color.BLUE)); board.addClip(new ClipEllipse(200, 150, 400, 250, Color.RED));
		  board.draw(canvas.getGraphicsContext2D()); stage.show();


	}

	public static void main(String[] args) {
		launch(args);
	}
}
