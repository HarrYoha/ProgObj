package pobj.pinboard.editor.commands;

import java.util.ArrayList;
import java.util.List;

import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipRect;
import pobj.pinboard.editor.EditorInterface;

public class CommandMove implements Command {

	private EditorInterface ei;
	private double x,y;
	private Clip c;
	
	
	public CommandMove(EditorInterface editor,Clip clip, double x,double y) {
		ei=editor;
		this.x=x;
		this.y=y;
		c=clip;
	}
	
	
	

	
	@Override
	public void execute() {

		int i=ei.getBoard().getContents().indexOf(c);
		ei.getBoard().getContents().get(i).move(x, y);
	}

	@Override
	public void undo() {

		int i=ei.getBoard().getContents().indexOf(c);
		ei.getBoard().getContents().get(i).move(-x, -y);	}
}
