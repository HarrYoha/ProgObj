package pobj.pinboard.editor.commands;

public class Pile {
	 private Noeud tete;
	 private int longueur;
	     
	    public void pile(){
	        tete = null;
	        longueur = 0;
	    }
	     
	    public void empiler(Command element){
	        Noeud nouveau = new Noeud(element);
	        nouveau.setSuivant(tete);
	        tete = nouveau;
	        longueur++;
	    }
	     
	    public Command depiler(){
	    	
	        Noeud n = this.tete;
	        this.tete = this.tete.getSuivant();
	        this.longueur--;
	         
	        return n.getCommand();
	    }
	    
	    public void clear() {
	    	tete = null;
	        longueur = 0;
	    }
	   
	    public boolean isEmpty() {
	    	return (this.longueur==0);
	    }
}
