package pobj.pinboard.editor.commands;

public class Noeud {
	  private Command valeur;
	  private  Noeud suivant;
	     
	    public Noeud(Command val){
	        this.valeur = val;
	        this.suivant = null;
	    }
	     
	    public Noeud(Noeud n){
	        this.valeur = n.valeur;
	        this.suivant = n.suivant;
	    }
	    public Noeud getSuivant() {
	    	return suivant;
	    }
	    public void setSuivant(Noeud suiv) {
	    	suivant=suiv;;
	    }
	    public Command getCommand() {
	    	return this.valeur;
	    }
}
