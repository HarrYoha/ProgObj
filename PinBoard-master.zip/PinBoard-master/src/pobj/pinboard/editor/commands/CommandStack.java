package pobj.pinboard.editor.commands;


public class CommandStack {
	
	private Pile Undo=new Pile();
	private Pile Redo=new Pile();
	
	public void addCommand(Command command) {
		Undo.empiler(command);
		Redo.clear();
	}
	
	public void undo() {
		Command d=Undo.depiler();
		d.undo();
		Redo.empiler(d);
	}
	
	public void redo() {
		Command d=Redo.depiler();
		d.execute();
		Undo.empiler(d);
		
	}
	
	public boolean isUndoEmpty() {
		return Undo.isEmpty();
	}
	
	public boolean isRedoEmpty() {
		return Redo.isEmpty();
		
	}
}
