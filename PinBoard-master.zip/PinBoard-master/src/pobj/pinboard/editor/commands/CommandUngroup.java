package pobj.pinboard.editor.commands;

import java.util.ArrayList;
import java.util.List;

import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipGroup;
import pobj.pinboard.document.Composite;
import pobj.pinboard.editor.EditorInterface;
import pobj.pinboard.editor.Selection;

public class CommandUngroup implements Command {
	
	private EditorInterface ei;
	private ClipGroup g;
	private List<Clip> lc;
	
	public CommandUngroup(EditorInterface e, ClipGroup g){
		ei = e;
		this.g = g;
		lc=new ArrayList<Clip>();
		lc.addAll(g.getClips());
	}

	@Override
	public void execute() {
		ei.getBoard().removeClip(g);
		for(Clip c:lc) {
			g.removeClip(c);
			ei.getBoard().addClip(c);
		}
	}

	@Override
	public void undo() {
		for(Clip c :lc) {
			g.addClip(c);
			ei.getBoard().removeClip(c);
		}
		ei.getBoard().addClip(g);
	}

}
