package pobj.pinboard.editor.commands;

import java.util.ArrayList;
import java.util.List;

import pobj.pinboard.document.Clip;
import pobj.pinboard.editor.EditorInterface;

public class CommandAdd implements Command {
	
	private List<Clip> clip;
	private EditorInterface ei;
	
	public CommandAdd(EditorInterface editor, Clip toAdd) {
		clip=new ArrayList<>();
		clip.add(toAdd);
		ei=editor;
	}
	
	public CommandAdd(EditorInterface editor, List<Clip> toAdd) {
		clip=new ArrayList<>();
		clip.addAll(toAdd);
		ei=editor;
	}
	
	@Override
	public void execute() {
		ei.getBoard().addClip( clip);
		
	}

	@Override
	public void undo() {
		ei.getBoard().removeClip(clip);
		
	}

}
