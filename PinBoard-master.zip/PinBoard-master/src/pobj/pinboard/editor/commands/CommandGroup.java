package pobj.pinboard.editor.commands;

import pobj.pinboard.editor.EditorInterface;

import java.util.ArrayList;
import java.util.List;

import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipGroup;

public class CommandGroup implements Command{
	
	
	private EditorInterface editor;
	private List<Clip> clips=new ArrayList<>();
	private ClipGroup cg=new ClipGroup();
	

	public CommandGroup(EditorInterface editor, List<Clip> clips) {
		
		this.editor=editor;
		for(Clip c : clips) {
			this.clips.add(c);
		}
	}
	
	
	@Override
	public void execute() {
		System.out.println("avant execute"+clips.size());
		cg.getClips().clear();
		for(Clip c :clips) {
			System.out.println("la");
			cg.addClip(c);
			editor.getBoard().removeClip(c);
		}
		editor.getBoard().addClip(cg);
		System.out.println("apres execute"+clips.size());
		
	}

	@Override
	public void undo() {
		System.out.println("avant undo"+clips.size());
		for (Clip c : cg.getClips()) {
			editor.getBoard().addClip(c);
		}
		editor.getBoard().removeClip(cg);
		System.out.println("apres undo"+clips.size());
	}
	
	public List<Clip> getClips() {
		return clips;
	}

}
