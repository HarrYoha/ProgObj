package pobj.pinboard.editor.tools;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipRect;
import pobj.pinboard.editor.EditorInterface;
import pobj.pinboard.editor.commands.Command;
import pobj.pinboard.editor.commands.CommandAdd;

public class ToolRect implements Tool {

	private double x, y;
	private Clip rectangle;
	private Color c;
	
	public ToolRect(Color c) {
		this.c=c;
	}
	public ToolRect() {
	}
	@Override
	public void press(EditorInterface i, MouseEvent e) {
		x = e.getX();
		y = e.getY();
		
		rectangle = new ClipRect(x, y, x, y, c);
	}

	@Override
	public void drag(EditorInterface i, MouseEvent e) {

		if (x > e.getX()) {
			if (y > e.getY())
				rectangle.setGeometry(e.getX(), e.getY(), x, y);

			else
				rectangle.setGeometry(e.getX(), y, x, e.getY());

		} else {
			if (y > e.getY())
				rectangle.setGeometry(x, e.getY(), e.getX(), y);

			else
				rectangle.setGeometry(x, y, e.getX(), e.getY());
		}
	}

	@Override
	public void release(EditorInterface i, MouseEvent e) {
		CommandAdd cmd=new CommandAdd(i, rectangle);
		cmd.execute();
		i.getUndoStack().addCommand(cmd);
		i.stackChanged();
		//i.getBoard().addClip(rectangle);
	}

	@Override
	public void drawFeedback(EditorInterface i, GraphicsContext gc) {
		
		gc.setStroke(rectangle.getColor());
		gc.strokeRect( rectangle.getLeft(), rectangle.getTop(),
		Math.abs(rectangle.getRight() - rectangle.getLeft()),Math.abs(rectangle.getBottom() - rectangle.getTop()));

	}

	@Override
	public String getName(EditorInterface editor) {
		return "Rectangle";
	}

	@Override
	public void setColour(Color c) {
		this.c=c;
		
	}
}
