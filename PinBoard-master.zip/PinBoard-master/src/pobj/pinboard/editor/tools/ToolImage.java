package pobj.pinboard.editor.tools;

import java.io.File;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import pobj.pinboard.document.ClipImage;
import pobj.pinboard.editor.EditorInterface;
import pobj.pinboard.editor.commands.CommandAdd;

public class ToolImage implements Tool{

	private double x, y;
	private ClipImage img;
	private File filename;
	public  ToolImage(File filename) {
		this.filename=filename;
	}
	
	@Override
	public void press(EditorInterface i, MouseEvent e) {
		x = e.getX();
		y = e.getY();
		img=new ClipImage(x, y, filename);
	}

	@Override
	public void drag(EditorInterface i, MouseEvent e) {

		if (x > e.getX()) {
			if (y > e.getY())
				img.setGeometry(e.getX(), e.getY(), x, y);

			else
				img.setGeometry(e.getX(), y, x, e.getY());

		} else {
			if (y > e.getY())
				img.setGeometry(x, e.getY(), e.getX(), y);

			else
				img.setGeometry(x, y, e.getX(), e.getY());
		}
		
	}

	@Override
	public void release(EditorInterface i, MouseEvent e) {

		//i.getBoard().addClip(img);
		CommandAdd cmd=new CommandAdd(i, img);
		cmd.execute();
		i.getUndoStack().addCommand(cmd);
		i.stackChanged();
	}

	@Override
	public void drawFeedback(EditorInterface i, GraphicsContext gc) {
		gc.setStroke(Color.WHITE);
		gc.strokeRect(x, y, img.getImg().getWidth(), img.getImg().getHeight());
	}

	@Override
	public String getName(EditorInterface editor) {
		return "Image";
	}

	@Override
	public void setColour(Color c) {
		// TODO Auto-generated method stub
		
	}
	
	
}
