package pobj.pinboard.editor.tools;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipEllipse;
import pobj.pinboard.editor.EditorInterface;
import pobj.pinboard.editor.commands.CommandAdd;

public class ToolEllipse implements Tool {

	private double x, y;
	private Clip ellipse;
	private Color c;

	public ToolEllipse(Color c) {
		this.c=c;
	}
	public ToolEllipse() {
	}
	@Override
	public void press(EditorInterface i, MouseEvent e) {
		x = e.getX();
		y = e.getY();
		

		ellipse = new ClipEllipse(x, y, x, y, c);
	}

	@Override
	public void drag(EditorInterface i, MouseEvent e) {

		if (x > e.getX()) {
			if (y > e.getY())
				ellipse.setGeometry(e.getX(), e.getY(), x, y);

			else
				ellipse.setGeometry(e.getX(), y, x, e.getY());

		} else if (y > e.getY())
			ellipse.setGeometry(x, e.getY(), e.getX(), y);

		else
			ellipse.setGeometry(x, y, e.getX(), e.getY());

	}

	@Override
	public void release(EditorInterface i, MouseEvent e) {
		CommandAdd cmd=new CommandAdd(i, ellipse);
		cmd.execute();
		i.getUndoStack().addCommand(cmd);
		i.stackChanged();
	}

	@Override
	public void drawFeedback(EditorInterface i, GraphicsContext gc) {
		gc.setStroke(ellipse.getColor());
		gc.strokeOval( ellipse.getLeft(), ellipse.getTop(),
				Math.abs(ellipse.getRight() - ellipse.getLeft()),Math.abs(ellipse.getBottom() - ellipse.getTop()));


	}

	@Override
	public String getName(EditorInterface editor) {
		return "Ellipse";
	}

	@Override
	public void setColour(Color c) {
		this.c=c;
		
	}

}
