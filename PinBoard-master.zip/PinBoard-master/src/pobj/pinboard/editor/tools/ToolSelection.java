package pobj.pinboard.editor.tools;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import pobj.pinboard.document.Board;
import pobj.pinboard.document.Clip;
import pobj.pinboard.editor.EditorInterface;
import pobj.pinboard.editor.EditorWindow;
import pobj.pinboard.editor.Selection;
import pobj.pinboard.editor.commands.Command;
import pobj.pinboard.editor.commands.CommandMove;

public class ToolSelection implements Tool {
	private double x_c,y_c; //on retiens ou nous avons cliquer
	private double x_press, y_press;
	
	
	@Override 
	public void press(EditorInterface i, MouseEvent e) {
		if (!e.isShiftDown())
			
			i.getSelection().select(i.getBoard(), e.getX(), e.getY());

		else
			i.getSelection().toogleSelect(i.getBoard(), e.getX(), e.getY());
		
		this.x_c=e.getX();
		this.y_c=e.getY();
		this.x_press=e.getX();
		this.y_press=e.getY();
	}

	@Override
	public void drag(EditorInterface i, MouseEvent e) {
		for (Clip c : i.getSelection().getContents()) {
			
		
		
		

			if (x_c > e.getX()) {
				if (y_c > e.getY())
					c.move(-(x_c-e.getX()), -(y_c-e.getY()));
					
				else
					c.move(-(x_c-e.getX()), e.getY()-y_c);

			} else {
			
				if (y_c > e.getY())
					c.move(e.getX()-x_c, -(y_c-e.getY()));
				else
					c.move(e.getX()-x_c, e.getY()-y_c);
			}
		}
		
		x_c=e.getX();
		y_c=e.getY();
	}

	@Override
	public void release(EditorInterface i, MouseEvent e) {
		for (Clip c : i.getSelection().getContents()) {
			Command co=new CommandMove(i, c,e.getX()-x_press, e.getY()-y_press);
			i.getUndoStack().addCommand(co);

		}
		
		
		x_c=0;
		y_c=0;
	}

	@Override
	public void drawFeedback(EditorInterface i, GraphicsContext gc) {
		i.getSelection().drawFeedback(gc);
	}

	@Override
	public String getName(EditorInterface editor) {
		return "Selectioner un ou plusieurs elements";
	}

	@Override
	public void setColour(Color c) {
		// TODO Auto-generated method stub
		
	}

}
