package pobj.pinboard.editor;

import java.util.ArrayList;
import java.util.List;

import pobj.pinboard.document.Clip;

public final class Clipboard {

	private List<Clip> list = new ArrayList<>();
	private List<ClipboardListener> listeners=new ArrayList<>();
	private static Clipboard clipboard=new Clipboard();
	
	private Clipboard() {
		
	}
	
	
	public void copyToClipboard(List<Clip> clips) {
		list.clear();
		for (Clip c : clips) {
			list.add(c.copy());
		}
		for(ClipboardListener cl:listeners)
			cl.clipboardChanged();
	}
	
	public List<Clip> copyFromClipboard(){
		List<Clip> l=new ArrayList<>();
		for(Clip c:list)
			l.add(c.copy());
		
		return l;
	}
	
	public void clear() {
		list.clear();
		for(ClipboardListener cl:listeners)
			cl.clipboardChanged();
			
	}
	
	public boolean isEmpty() {
		return list.isEmpty();
	}
	
	public static Clipboard getInstance() {
		return clipboard;
	}


	
	public void addListener(ClipboardListener listener) {
		listeners.add(listener);
	}
	
	public void removeListener(ClipboardListener listener) {
		listeners.remove(listener);
	}

}
