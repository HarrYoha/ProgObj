package pobj.pinboard.editor;

import java.io.File;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import pobj.pinboard.document.Board;
import pobj.pinboard.document.Clip;
import pobj.pinboard.document.ClipGroup;
import pobj.pinboard.editor.commands.CommandAdd;
import pobj.pinboard.editor.commands.CommandGroup;
import pobj.pinboard.editor.commands.CommandMove;
import pobj.pinboard.editor.commands.CommandStack;
import pobj.pinboard.editor.commands.CommandUngroup;
import pobj.pinboard.editor.tools.Tool;
import pobj.pinboard.editor.tools.ToolEllipse;
import pobj.pinboard.editor.tools.ToolImage;
import pobj.pinboard.editor.tools.ToolRect;
import pobj.pinboard.editor.tools.ToolSelection;

public class EditorWindow implements EditorInterface, ClipboardListener {

	private Board board;
	private Scene scene;
	private Tool tool;
	private Color color = Color.BLACK;
	private Canvas canvas;
	private Selection selection = new Selection();
	private int width = 700;
	private int height = 500;
	private MenuItem paste;
	private CommandStack cmd = new CommandStack();
	private MenuItem undo = new MenuItem("Undo");
	private MenuItem redo = new MenuItem("Redo");

	public EditorWindow(Stage stage) {

		tool = new ToolRect(color);
		this.board = new Board();

		stage.setTitle("pinboard");
		VBox vbox = new VBox();

		// Canvas
		canvas = new Canvas(width, height);

		// MenuBar & Menu
		Menu file = new Menu("File");
		Menu edit = new Menu("Edit");
		Menu tools = new Menu("Tools");
		MenuBar menuBar = new MenuBar(file, edit, tools);

		// MenuItem pour Menu file

		MenuItem neww = new MenuItem("New");
		MenuItem close = new MenuItem("Close");

		MenuItem copy = new MenuItem("Copy");
		paste = new MenuItem("Paste");
		MenuItem delete = new MenuItem("Delete");
		MenuItem group = new MenuItem("Group");
		MenuItem ungroup = new MenuItem("Ungroup");
		

		Clipboard.getInstance().addListener(this);
		clipboardChanged();
		stackChanged();
		RstackChanged();
		close.setOnAction((e) -> {
			Clipboard.getInstance().removeListener(this);
			stage.close();
		});

		neww.setOnAction((e) -> {
			new EditorWindow(new Stage());
		});

		copy.setOnAction((e) -> {
			Clipboard.getInstance().copyToClipboard((selection.getContents()));
			;
		});

		paste.setOnAction((e) -> {
			// board.addClip(Clipboard.getInstance().copyFromClipboard());
			CommandAdd cmdAdd = new CommandAdd(this, Clipboard.getInstance().copyFromClipboard());
			cmdAdd.execute();
			cmd.addCommand(cmdAdd);
			stackChanged();
			RstackChanged();

		});

		group.setOnAction((e) -> {
			CommandGroup cmdGroup = new CommandGroup(this, selection.getContents());
			cmdGroup.execute(); 
			cmd.addCommand(cmdGroup);
			stackChanged();
			RstackChanged();
		});

		ungroup.setOnAction((e) -> {
			for (Clip c : selection.getContents()) {
				if (c instanceof ClipGroup) {
					ClipGroup d = (ClipGroup) c;
					CommandUngroup cmdUngroup = new CommandUngroup(this, d);
					cmdUngroup.execute();
					cmd.addCommand(cmdUngroup);
					
				}
				
			}
			stackChanged();
			RstackChanged();

		});

		undo.setOnAction((e) -> {
			cmd.undo();
			canvas.getGraphicsContext2D().setFill(Color.WHITE);
			canvas.getGraphicsContext2D().fillRect(0, 0, width, height);
			board.draw(canvas.getGraphicsContext2D());
			stackChanged();
			RstackChanged();
		});

		redo.setOnAction((e) -> {

			cmd.redo();
			canvas.getGraphicsContext2D().setFill(Color.WHITE);
			canvas.getGraphicsContext2D().fillRect(0, 0, width, height);
			board.draw(canvas.getGraphicsContext2D());
			stackChanged();
			RstackChanged();
		});

		delete.setOnAction((e) -> {
			selection.delete(board);
			canvas.getGraphicsContext2D().setFill(Color.WHITE);
			canvas.getGraphicsContext2D().fillRect(0, 0, width, height);
			board.draw(canvas.getGraphicsContext2D());
			stackChanged();
			RstackChanged();
		});

		file.getItems().addAll(neww, new SeparatorMenuItem(), close);

		edit.getItems().addAll(copy, new SeparatorMenuItem(), paste, new SeparatorMenuItem(), delete,
				new SeparatorMenuItem(), group, new SeparatorMenuItem(), ungroup, new SeparatorMenuItem(), undo,
				new SeparatorMenuItem(), redo);

		// Toolbar & buttons
		Button box = new Button("Box");
		Button ellipse = new Button("Ellipse");
		Button image = new Button("Img...");
		Button select = new Button("Select");

		ToolBar toolBar = new ToolBar(box, ellipse, image, select);

		MenuItem boxItem = new MenuItem("Box");
		MenuItem ellipseItem = new MenuItem("Ellipse");
		MenuItem imageItem = new MenuItem("Image");
		tools.getItems().addAll(boxItem, new SeparatorMenuItem(), ellipseItem, new SeparatorMenuItem(), imageItem);
		// Separator & Label
		Separator separator = new Separator();

		Button bleu = new Button("", new Rectangle(30, 20, Color.BLUE));
		Button rouge = new Button("", new Rectangle(30, 20, Color.RED));
		Button vert = new Button("", new Rectangle(30, 20, Color.GREEN));
		Button jaune = new Button("", new Rectangle(30, 20, Color.YELLOW));
		Button noir = new Button("", new Rectangle(30, 20, Color.BLACK));
		Button rose = new Button("", new Rectangle(30, 20, Color.PINK));
		Button marron = new Button("", new Rectangle(30, 20, Color.BROWN));

		ToolBar toolBarColour = new ToolBar(bleu, rouge, vert, jaune, noir, rose, marron);
		MenuItem bleuItem = new MenuItem("");
		MenuItem rougeItem = new MenuItem("");
		MenuItem VertItem = new MenuItem("");
		MenuItem JauneItem = new MenuItem("");
		MenuItem NoirItem = new MenuItem("");
		MenuItem RoseItem = new MenuItem("");
		MenuItem MarronItem = new MenuItem("");

		Label label = new Label("Label test");
		vbox.getChildren().addAll(menuBar, toolBar, toolBarColour, canvas, separator, label);

		Scene scene = new Scene(vbox);
		stage.setScene(scene);
		stage.show();

		stage.setOnCloseRequest(event -> {
			Clipboard.getInstance().removeListener(this);
		});

		box.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {

				tool = new ToolRect(color);
				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		image.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				FileChooser fileChooser = new FileChooser();
				File selectedFile = fileChooser.showOpenDialog(stage);

				fileChooser.setTitle("Open Resource File");
				if (selectedFile != null) {

				}
				tool = new ToolImage(selectedFile);
				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		select.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				tool = new ToolSelection();
				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		boxItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				tool = new ToolRect(color);

				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});
		marron.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BROWN;

				label.textProperty().set(tool.getName(EditorWindow.this) + " marron");
			}
		});
		MarronItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BROWN;

				label.textProperty().set(tool.getName(EditorWindow.this) + " marron");
			}
		});
		rouge.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.RED;

				label.textProperty().set(tool.getName(EditorWindow.this) + " rouge");
			}
		});
		rougeItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.RED;

				label.textProperty().set(tool.getName(EditorWindow.this) + " rouge");
			}
		});
		bleu.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BLUE;

				label.textProperty().set(tool.getName(EditorWindow.this) + " bleu");
			}
		});
		bleuItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BLUE;

				label.textProperty().set(tool.getName(EditorWindow.this) + " bleu");
			}
		});
		vert.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.GREEN;

				label.textProperty().set(tool.getName(EditorWindow.this) + " vert");
			}
		});
		VertItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.GREEN;

				label.textProperty().set(tool.getName(EditorWindow.this) + " vert");
			}
		});
		jaune.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.YELLOW;

				label.textProperty().set(tool.getName(EditorWindow.this) + " jaune");
			}
		});

		JauneItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.YELLOW;

				label.textProperty().set(tool.getName(EditorWindow.this) + " jaune");
			}
		});
		noir.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BLACK;

				label.textProperty().set(tool.getName(EditorWindow.this) + " noir");
			}
		});

		NoirItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.BLACK;

				label.textProperty().set(tool.getName(EditorWindow.this) + " noir");
			}
		});

		rose.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.PINK;

				label.textProperty().set(tool.getName(EditorWindow.this) + " rose");
			}
		});

		RoseItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				color = Color.PINK;

				label.textProperty().set(tool.getName(EditorWindow.this) + " rose");
			}
		});
		ellipse.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				tool = new ToolEllipse(color);

				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		ellipseItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				tool = new ToolEllipse(color);

				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		imageItem.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				tool = new ToolEllipse(color);

				label.textProperty().set(tool.getName(EditorWindow.this));
			}
		});

		canvas.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent e) {
				tool.setColour(color);
				tool.press(EditorWindow.this, e);
				stackChanged();
				RstackChanged();
			}
		});

		canvas.setOnMouseDragged(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent e) {
				tool.drag(EditorWindow.this, e);
				canvas.getGraphicsContext2D().setFill(Color.WHITE);
				canvas.getGraphicsContext2D().fillRect(0, 0, width, height);
				board.draw(canvas.getGraphicsContext2D());
				tool.setColour(color);
				tool.drawFeedback(EditorWindow.this, canvas.getGraphicsContext2D());
				stackChanged();
				RstackChanged();

			}
		});

		canvas.setOnMouseReleased(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent e) {
				tool.release(EditorWindow.this, e);
				
				canvas.getGraphicsContext2D().setFill(Color.WHITE);
				canvas.getGraphicsContext2D().fillRect(0, 0, width, height);
				tool.setColour(color);
				canvas.getGraphicsContext2D().setStroke(Color.GREEN);
				for (Clip c : selection.getContents()) {
					canvas.getGraphicsContext2D().strokeRect(c.getLeft(), c.getTop(), c.getRight() - c.getLeft(),
							c.getBottom() - c.getTop());
				}
				board.draw(canvas.getGraphicsContext2D());
				stackChanged();
				RstackChanged();
			}
		});

	}

	public int getHeight() {
		return height;
	}

	public int getWidth() {
		return width;
	}

	@Override
	public Board getBoard() {
		return board;
	}

	@Override
	public Selection getSelection() {
		return selection;
	}

	@Override
	public void clipboardChanged() {
		if (Clipboard.getInstance().isEmpty())
			paste.setDisable(true);
		else
			paste.setDisable(false);
	}

	public void stackChanged() {
		if (cmd.isUndoEmpty())
			undo.setDisable(true);
			
		else
			undo.setDisable(false);			
	}
	
	public void RstackChanged() {
		if (cmd.isRedoEmpty())
			redo.setDisable(true);
			
		else
			redo.setDisable(false);			
	}
	
	
	public Canvas getCanvas() {
		return canvas;
	}

	public CommandStack getUndoStack() {
		return cmd;
	}
}
