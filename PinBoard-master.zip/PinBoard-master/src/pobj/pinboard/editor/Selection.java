package pobj.pinboard.editor;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import pobj.pinboard.document.Board;
import pobj.pinboard.document.Clip;

public class Selection {

	private List<Clip> list = new ArrayList<>();
	
	public void select(Board board, double x, double y) {
		list.clear();
		for (Clip c : board.getContents()) {
			if (c.isSelected(x, y)) {
				list.add(c);
				break;
			}
		}
	}

	public void toogleSelect(Board board, double x, double y) {
		
		for (Clip c : board.getContents()) {
			if (c.isSelected(x, y)) {
				if (list.contains(c)) {
					list.remove(c);
					break;
				} else {
					list.add(c);
					break;
				}
			}
		}

	}

	public void clear() {
		list.clear();
	}

	public void drawFeedback(GraphicsContext gc) {
		gc.setStroke(Color.BLACK);
		for (Clip c : list) {
			gc.strokeRect(c.getLeft(), c.getTop(), c.getRight() - c.getLeft(), c.getBottom() - c.getTop());
		}
	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	
	public void delete(Board b) {
		for (Clip c:list) {
			if(b.getContents().contains(c))
				b.removeClip(c);
			
		}
	}
	
	
	public List<Clip> getContents() {
		return list;
	}
}
