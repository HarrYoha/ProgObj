package pobj.pinboard.editor;



import javafx.scene.canvas.Canvas;
import pobj.pinboard.document.Board;
import pobj.pinboard.editor.commands.CommandStack;

public interface EditorInterface {
	public Board  getBoard();
	public Selection getSelection();
	public CommandStack getUndoStack();
	public void stackChanged();
	public void RstackChanged(); 
	
}
