package pobj.expr;

public class VisitorConstant implements IVisitor<Boolean> {

	@Override
	public Boolean visit(Constant c) {
		return true;
	}

	@Override
	public Boolean visit(Add e) {
		boolean b=e.getLeft().accept(this);
		boolean c=e.getRight().accept(this);
		return b&&c;
	}

	@Override
	public Boolean visit(Mult e) {
		boolean b=e.getLeft().accept(this);
		boolean c=e.getRight().accept(this);
		return b&&c;
	}

	@Override
	public Boolean visit(Var v) {
		return false;
	}

}
