package pobj.expr;

public class Constant implements Expression {

	private int value;

	public Constant(int v) {
		value = v;
	}

	public Constant() {
		value = 0;
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (getClass() != o.getClass())
			return false;

		Constant v = (Constant) o;

		 return value != v.value;
			
	}

	public int getValue() {
		return value;
	}
	
	
	public String toString () {
		return Integer.toString(value);
	}

	@Override
	public int eval() {
		// TODO Auto-generated method stub
		return value;
	}

	@Override
	public <T> T accept(IVisitor<T> t) {
		// TODO Auto-generated method stub
		return t.visit(this);
	}
}
