package pobj.expr;

import java.util.HashMap;

public class VisitorSimplify implements IVisitor<Expression> {

	@Override
	public Expression visit(Constant c) {
		return c;
	}

	@Override
	public Expression visit(Add e) {
		
		
		if (Question10.isConstant(e)) {
			int a=Question10.evalConstantExpression(e);
			return new Constant(a);
		}
		
		if((e.getLeft() instanceof Var) && (e.getRight() instanceof Var)) {
			return e;
		}
		
		
		if(e.getLeft() instanceof Var) {
			IVisitor<Integer> vtc2=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getRight().accept(vtc2)==0) {
				return e.getLeft();
			}
			
		}
		
		if(e.getRight() instanceof Var) {
			IVisitor<Integer> vtc1=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getLeft().accept(vtc1)==0) {
				System.out.println("laa");
				return e.getRight();
			}
			
			
		}
		return e;
		
	}

	@Override
	public Expression visit(Mult e) {
		
		if (Question10.isConstant(e)) {
			
			int a=Question10.evalConstantExpression(e);
			return new Constant(a);
		}
		
		if((e.getLeft() instanceof Var) && (e.getRight() instanceof Var)) {
			return e;
		}
		
		
		if(e.getLeft() instanceof Var) {
			IVisitor<Integer> vtc2=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getRight().accept(vtc2)==0) {
				return new Constant(0);
			}
			IVisitor<Integer> vtc4=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getRight().accept(vtc4)==1) {
				return e.getLeft();
			}
		}
		
		if(e.getRight() instanceof Var) {
			IVisitor<Integer> vtc1=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getLeft().accept(vtc1)==0) {
				System.out.println("laa");
				return new Constant(0);
			}
			System.out.println("ici");
			IVisitor<Integer> vtc3=new VisitorEvalVar(new HashMap<String,Integer>());
			if(e.getLeft().accept(vtc3)==1) {
				return e.getRight();
			}
			
			
		}
		
		return e;
	}

	@Override
	public Expression visit(Var v) {
		return v;
	}

}
