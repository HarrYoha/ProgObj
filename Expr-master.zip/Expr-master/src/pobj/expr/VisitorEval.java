package pobj.expr;

public class VisitorEval implements IVisitor<Integer> {

	@Override
	public Integer visit(Constant c) {
		return c.getValue();
	}

	@Override
	public Integer visit(Add e) {
		int a=e.getLeft().accept(this);
		int b=e.getRight().accept(this);
		return a+b;
	}

	@Override
	public Integer visit(Mult e) {
		int a=e.getLeft().accept(this);
		int b=e.getRight().accept(this);
		return a*b;
	}

	@Override
	public Integer visit(Var v) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

}
