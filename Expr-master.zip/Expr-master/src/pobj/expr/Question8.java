package pobj.expr;

import java.util.HashMap;
import java.util.Map;

public class Question8 {
	
	
	public static Map<String,Integer> env1(){
		return new HashMap<String,Integer>();
	}
	
	public static Map<String,Integer> env2(){
		Map<String,Integer> m= new HashMap<String,Integer>();
		m.put("x", 10);
		m.put("y",20);
		return m;
	}
	
	public static Map<String,Integer> env3(){
		Map<String,Integer> m= new HashMap<String,Integer>();
		m.put("z", 9);
		return m;
	}
}
