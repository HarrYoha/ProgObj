package pobj.expr;

public class Add extends BinOp implements Expression{


	private final Expression left,right;
	
	public Add(Expression left,Expression right) {
		this.left=left;
		this.right=right;
	}
	
	public String toString() {
			return "( "+left.toString()+" + "+ right.toString()+" )";
	}
	
	
	public Expression getLeft() {
		return left;
	}
	
	
	public Expression getRight() {
		return right;
	}

	
	
	@Override
	public int eval() {	
		return left.eval()+right.eval();
	}

	@Override
	public <T> T accept(IVisitor<T> t) {
		return t.visit(this);
	}
	
	
	
}
