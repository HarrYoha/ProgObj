package pobj.expr;

public abstract class BinOp {

	private Expression left,right;
	
	

	public Expression getLeft() {
		return left;
	}
	
	public Expression getRight() {
		return right;
	}
}
