package pobj.expr;

public class Var implements Expression{

	private final String name;
	
	public Var(String var) {
		name=var;
	}
	
	
	public String getName() {
		return name;
	}
	
	public boolean equals(Object o) {
		if(this==o)
			return true;
		if(getClass()!=o.getClass())
			return false;
		Var v=(Var)o;
		if( v.name==name)
			return true;
		return false;
	}
	
	public String toString() {
		return name;
	}


	@Override
	public int eval() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException();
	}


	@Override
	public <T> T accept(IVisitor<T> t) {
		// TODO Auto-generated method stub
		return t.visit(this);
	}
}
