package pobj.expr;

public class Question4 {

	
	public static Expression e1() {
		Expression deux=new Constant(2);
		Expression trois=new Constant(3);
		Expression quatre=new Constant(4);
		
		Expression add=new Add(deux, trois);
		Expression mult=new Mult(add, quatre);	
	
		return mult;
	}
	
	
	
	public static Expression e2() {
		Expression x=new Var("x");
		Expression trois=new Constant(3);
		Expression quatre=new Constant(4);
		
		Expression add=new Add(x, trois);
		Expression ad=new Add(x, quatre);
		
		Expression mult=new Mult(add, ad);	
	
		return mult;
	}
	
	
	public static Expression e3() {
		Expression x=new Var("x");
		Expression dix=new Constant(10);
		Expression y=new Var("y");
		Expression moins8=new Constant(-8);
		
		Expression add=new Add(x, dix);
		Expression ad=new Add(y, moins8);
		
		Expression mult=new Mult(add, ad);	
	
		return mult;
	}
	
}
