package pobj.expr;

public class Mult extends BinOp implements Expression{


	private final Expression left,right;
	
	public Mult(Expression left,Expression right) {
		this.left=left;
		this.right=right;
	}
	
	public String toString() {
			return left.toString()+" * "+ right.toString();
	}
	
	
	public Expression getLeft() {
		return left;
	}
	
	
	public Expression getRight() {
		return right;
	}

	@Override
	public int eval() {

		// TODO Auto-generated method stub
		return right.eval()*left.eval();
	}

	@Override
	public <T> T accept(IVisitor<T> t) {
		// TODO Auto-generated method stub
		return t.visit(this);
	}
	
	
	
	
}
