package pobj.expr;

public class VisitorDerive implements IVisitor<Expression> {

	private Var var;

	public VisitorDerive(Var var) {
		this.var=var;
	}
	
	@Override
	public Expression visit(Constant c) {
		return new Constant(0);
	}

	@Override
	public Expression visit(Add e) {
		Expression a=e.getLeft().accept(this);
		Expression b=e.getRight().accept(this);
		return new Add(a, b);
	}

	@Override
	public Expression visit(Mult e) {
		Expression e2p=e.getRight().accept(this);
		Expression e1p=e.getLeft().accept(this);
		
		return new Add(new Mult(e.getLeft(),e2p),new Mult(e1p,e.getRight()));
	}

	@Override
	public Expression visit(Var v) {
		if(this.var.getName().equals(v.getName())) {
			return new Constant(1);
		}
		return new Constant(0);
	}

}
