package pobj.tme5;

public class MultiParserTest {
	
	public static void main(String[] args) {
		try {
			MultiSetParser.parse("data/Mon_fichier.txt");
		} catch (InvalidMultiSetFormat e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
