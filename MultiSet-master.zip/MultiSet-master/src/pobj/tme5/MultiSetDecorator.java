package pobj.tme5;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import pobj.tme4.MultiSet;

public class MultiSetDecorator<T> implements MultiSet<T> {
	
	private MultiSet<T> decorated;
	
	public MultiSetDecorator(MultiSet<T> decorated) {
		this.decorated = decorated;
	}
	
	@Override
	public boolean addAll(Collection<? extends T> c) {
		return decorated.addAll(c);
	}

	@Override
	public boolean contains(Object o) {
		return decorated.contains(o);
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return decorated.containsAll(c);
	}

	@Override
	public boolean isEmpty() {
		return decorated.isEmpty();
	}

	@Override
	public Iterator<T> iterator() {
		return decorated.iterator();
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		return  decorated.removeAll(c);
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		return decorated.retainAll(c);
	}

	@Override
	public Object[] toArray() {
		return decorated.toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return decorated.toArray(a);
	}

	@Override
	public int compare(T o1, T o2) {
		return decorated.compare(o1, o2);
	}

	@Override
	public boolean add(T e, int count) {
		boolean b=decorated.add(e, count);
		assert isConsistent();
		return b; 
		
		
	}

	@Override
	public boolean add(T e) {
		return decorated.add(e);
	}

	@Override
	public boolean remove(Object e) {
		boolean b=decorated.remove(e);
		assert isConsistent();
		return b;
		}

	@Override
	public boolean remove(Object e, int count) {
		return decorated.remove(e, count);
	}

	@Override
	public int count(T o) {
		return decorated.count(o);
	}

	@Override
	public void clear() {
		decorated.clear();
		assert isConsistent();

	}

	@Override
	public int size() {
		return decorated.size();
	}

	@Override
	public List<T> elements() {
		return decorated.elements();
	}
	public boolean isConsistent() {
		return  decorated.isConsistent();
	}

}
