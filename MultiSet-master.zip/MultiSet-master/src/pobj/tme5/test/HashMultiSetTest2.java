package pobj.tme5.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import pobj.tme4.MultiSet;
import pobj.tme5.MultiSetDecorator;

public class HashMultiSetTest2 {

	private MultiSet<String> m;
	MultiSetDecorator<String> d;
	@Before
	public void before() {
		m = new pobj.tme5.HashMultiSet<>();
		d=new MultiSetDecorator<String>(m);
	}
	
	@Test
	public void testRemove1() {
		d.add("a", 2);
		d.remove("a", 1);
		assertEquals(1, d.count("a"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testRemove2() {
		d.add("a");
		d.remove("a", -1);
	}

	@Test
	public void testSize() {
		d.add("a");
		d.add("a", 5);

		assertEquals(6, m.size());
	}
	@Test
	public void testtoString() {
		m.add("a");
		System.out.println(m.toString());
		assertEquals("a:1 ", m.toString());
	}
	@Test
	public void testClear() {
		m.add("a",2);
		m.clear();
		System.out.println(m.size());
		assertEquals(0, m.size());
	}
	
	@Test
	public void testComplexe(){
		
		m.add("a",10);
		m.add("b",5);
		assertEquals(15,m.size());
		m.remove("a",2);
		assertEquals(13,m.size());
		m.remove("b",8);
		assertEquals(8,m.size());

	}
	@Test 
	public void TestParticulier() {
		m.add("a", 0);
		assertEquals(0,m.size());
		m.remove("a", 0);
		assertEquals(0,m.size());
		m.add("a", 100);
		m.remove("a", 100);
		assertEquals(0,m.size());
		assertEquals(0,m.count("u"));

	}
}
