package pobj.tme5.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import pobj.tme4.MultiSet;
import pobj.tme5.HashMultiSet;
import pobj.tme5.MultiSetDecorator;

public class HashMultiSetTest {
	
	private MultiSet<String> m;
	MultiSetDecorator<String> d;
	@Before
	public void before() {
		m = new HashMultiSet<>();
		d=new MultiSetDecorator<String>(m);
	}
	
	@Test 
	public void testAdd1() {
		d.add("a");
		d.add("a",5);
		assertEquals(6, d.count("a"));
	}

	@Test(expected = IllegalArgumentException.class) 
	public void testAdd2() {
		d.add("a");
		d.add("a",-1);
	}
	
	@Test
	public void testClear() {
		d.add("a",2);
		d.clear();
		System.out.println(d.size());
		assertEquals(0, d.size());
	}
	
}
