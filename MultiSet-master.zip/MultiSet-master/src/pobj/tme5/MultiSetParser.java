package pobj.tme5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import pobj.tme4.MultiSet;

public class MultiSetParser {
	
	
	public static MultiSet<String> parse(String fileName) throws InvalidMultiSetFormat {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(fileName));
		} catch (FileNotFoundException e1) {
			throw new InvalidMultiSetFormat("erreur pas de fichier", e1);
		} 
		String line; 
		MultiSet<String> m=new HashMultiSet<String>();
		try {
			while ((line = br.readLine())!=null) {
					String [] tab=line.split(":");
					System.out.println(tab[0]);
					System.out.println(tab[1]);
					m.add(tab[0], Integer.decode(tab[1]));
			}
			System.out.println(m.toString());
		} catch (NumberFormatException e) {
			throw new InvalidMultiSetFormat("erreur format", e);
		
		} catch (IOException e) {
			throw new InvalidMultiSetFormat("erreur entree-sortie", e);

		}
		return m;
			
	}
}
