package pobj.tme4;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class NaiveMultiSet<T> extends AbstractCollection<T> implements MultiSet<T> {
	
	ArrayList<T> m;
	int size=0;
	
	public NaiveMultiSet() {
		this.m=new ArrayList<>();
	}
	
	public NaiveMultiSet(ArrayList<T> m) {
		this.m=m;
		size=m.size();
	}

	@Override
	public int compare(T o1, T o2) {
		int i1=0, i2=0;
		if(m.contains(o1) && m.contains(o2)) {
			for( T m:m) {
				if(o1.equals(m))  i1++;
				if(o2.equals(m))  i2++;
			}

			if (i1>i2) {
				return -1;
			}
			if (i1<i2) {
				return 1;
			}
			if (i1==i2) {
				return 0;
			}
		}
		return 0;
	}

	@Override
	public boolean add(T e, int count) {
		for(int i=0;i<count;i++) {
			m.add(e);
			size++;
		}
		return true;
	}
	@Override
	public boolean add(T e) {
		return add(e,1);
	}
	
	@Override
	public boolean remove(Object e) {
		return remove(e,1);
	}
	
	
	@Override
	public boolean remove(Object e, int count) {
		int cpt=count;
		for(T t: m) {
			if (t.equals(e)) {
				m.remove(t);
				count--;
				if (count==0) {
					break;
				}
			}
		}
		return true ;
	}

	@Override
	public int count(T o) {
		int cpt=0;
		for(T t: m) {
			if (t.equals(o)) {
				cpt++;
			}
		}
		return cpt;
	}

	@Override
	public List<T> elements() {
		Set<T> s=new HashSet<T>();
		List<T> l= new ArrayList<T>();
		for (T st : m) {
			s.add(st);
		}
		for(T ss: s) {
			l.add(ss);
		}
		return l;
	}

	@Override
	public Iterator<T> iterator() {
		return m.iterator();
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isConsistent() {
		// TODO Auto-generated method stub
		return false;
	}

	
	
	
}
