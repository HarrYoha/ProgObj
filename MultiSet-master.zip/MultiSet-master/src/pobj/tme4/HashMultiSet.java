package pobj.tme4;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMultiSet<T> extends AbstractCollection<T> implements MultiSet<T>,Iterable<T>   {
	
	private HashMap<T,Integer> dict;
	
	private int  size;
	
	
	public HashMultiSet() {
		dict= new HashMap<T,Integer>();
		size=0;
	}
	
	public HashMultiSet(Collection<T> c ) {
		for(T t: c) {
			if (dict.get(t)==null) 
				dict.put(t, 1);
			else
				dict.put(t, dict.get(t)+1);
		}
		size=0;
	}
	@Override
	public boolean add(T e, int count) {
		System.out.println("je suis la ");
			if (!dict.containsKey(e)) {
				dict.put(e, count);
				size+=count;
				return true;
			}else{
				dict.put(e, dict.get(e)+count);
				size+=count;
				return true;
			}
			
	}
	@Override
	public boolean add(T e) {
		return add(e,1);
	
	}
	@Override
	public boolean remove(Object e) {
		return remove(e,1);
	}
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object e, int count) {
		dict.put((T) e, dict.get(e)-count);
		size-=count;
		if(dict.get(e)<=0){
			if(dict.get(e)<0){
				size+=(-dict.get(e));
			}
			dict.remove(e);
		}
		
		return true;
		
			
	}
	@Override
	public int count(T o) {
		if (dict.containsKey(o)) {
			return dict.get(o);
		} else {
			return  0;
		}
	}
	@Override
	public void clear() {
		
		dict.clear();
		size=0;
	}
	@Override
	public int size() {
		return size;
	}
	class HashMultiSetIterator<T> implements Iterator<T> {
		
		//private static final Exception NoSuchElementException = null;
		private int cpt=0;
		private Iterator<Map.Entry<T, Integer>> Niterateur;
		private HashMap<T,Integer> h;
		private Entry<T, Integer> me;

		
		public HashMultiSetIterator(HashMap<T,Integer> h){
			Niterateur=h.entrySet().iterator();
			this.h=h;
			//Niterateur.next();
			//System.out.println(Niterateur.next().getKey());
			me=Niterateur.next();
			
		}
		
		
		@Override
		public boolean hasNext() {
			if(cpt< me.getValue()) {
				return true;
			}else {
				return Niterateur.hasNext();
			}
		}

		@Override
		public T next() {
			
			if(cpt< me.getValue()) {
				cpt++;
				return me.getKey();
			}else {
				if (hasNext()) {
					cpt=1;
					me=Niterateur.next();
					return me.getKey();
				}else {
					return null;
				}
			}
		}
		
	}
	

	@Override
	public Iterator<T> iterator() {
		return (new HashMultiSetIterator(this.dict));
	}

	@Override
	public List<T> elements() {
		Set<T> s=new HashSet<T>();
		List<T> l= new ArrayList<T>();
		for (T st : dict.keySet()) {
			s.add(st);
		}
		for(T ss: s) {
			l.add(ss);
		}
		return l;
	}

	@Override
	public int compare(T o1, T o2) {
		if(dict.containsKey(o1) && dict.containsKey(o2)) {
			int i1=dict.get(o1);
			int i2=dict.get(o2);
			//System.out.println(o1+" "+dict.get(o1));
			//System.out.println(o2+" "+dict.get(o2));

			if (i1>i2) {
				return -1;
			}
			if (i1<i2) {
				return 1;
			}
			if (i1==i2) {
				return 0;
			}
		}
		return 0;
	}

	@Override
	public boolean isConsistent() {
		// TODO Auto-generated method stub
		return false;
	}

	

}
