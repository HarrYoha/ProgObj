package pobj.tme4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import pobj.util.Chrono;

public  class WordCount {
	public static void wordcount( MultiSet<String> ms) throws IOException {
		String file = "data/WarAndPeace.txt"; 
		BufferedReader br = new BufferedReader(new FileReader(file)); 
		String line; 
		while ((line = br.readLine())!=null) { 
			//System.out.println(line);
			for (String word : line.split("\\P{L}+")) { 
				if (word.equals("")) continue; // ignore les mots vides 
				else  ms.add(word);
				//System.out.println(word);
			}
		}
		List<String> l=ms.elements();
		
		System.out.println("-----------------------------------");

		Collections.sort(l,ms);
		int i=0;
		for(String s: l) {
			System.out.println(s);
			System.out.println("i"+i);
			i++;
			if(i>10) { break; }
		}
		System.out.println("--------------------------------fin");
	}
	
	public static void main(String args[] ) {
		HashMultiSet<String> sortie=new HashMultiSet<String>();
		NaiveMultiSet<String> so=new NaiveMultiSet<String>();
		try {
			Chrono chrono=new Chrono();
			wordcount(sortie);
			chrono.stop();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	

	
}
