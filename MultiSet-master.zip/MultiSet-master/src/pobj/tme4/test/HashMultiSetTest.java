package pobj.tme4.test;
import pobj.tme4.*;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import pobj.tme4.HashMultiSet;
import pobj.tme4.MultiSet;

public class HashMultiSetTest {

	@Test
	public void testAdd() {
		MultiSet<String> m = new HashMultiSet<>();
		/*m.add("a");
		m.add("a",5);
		System.out.println(m.count("a"));
		assertEquals(6, m.count("a"));
		m.remove("a",1);
		assertEquals(5, m.count("a"));
		System.out.println(m.size());

		m.add("b",10);
		m.add("b",10);
		System.out.println( m.count("b"));
		System.out.println(m.size());

		assertEquals(20, m.count("b"));
		System.out.println(m.size());
		m.remove("b");
		System.out.println(m.size());*/
		
		m.add("a",3);
		m.add("b");
		m.add("c",2);
		System.out.println(m.size());

	}

}
