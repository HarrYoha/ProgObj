package pobj.motx.tme2;

public interface IContrainte {
	public int reduce (GrillePotentiel grille);
}

