package pobj.motx.tme2;

import java.util.List;
import java.util.ArrayList;

public class EnsembleLettre {

	private List<Character> listeLettre = new ArrayList<>();

	public void add(char c) {
		if (!listeLettre.contains(c))
			listeLettre.add(c);
	}

	public List<Character> getListeLettre(List<Character> l) {
		return listeLettre;
	}

	public EnsembleLettre calcInter(EnsembleLettre l1, EnsembleLettre l2) {
		EnsembleLettre ltmp = new EnsembleLettre();
		for (char c : l1.listeLettre) {
			if (l2.contains(c)) {
				if (!ltmp.contains(c))
					ltmp.add(c);
			}
		}
		return ltmp;
	}

	public boolean contains(char c) {
		return (listeLettre.contains(c));
	}

	public int size() {
		return listeLettre.size();
	}

}