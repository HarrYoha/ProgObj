package pobj.motx.tme2;

import java.util.ArrayList;
import java.util.List;

import pobj.motx.tme1.Case;
import pobj.motx.tme1.Emplacement;
import pobj.motx.tme1.GrillePlaces;

public class GrillePotentiel {
	
	
	private GrillePlaces gr;
	private Dictionnaire dico;
	private List<Dictionnaire> motsPot; //liste de dictionnaire pour chaque emplacement 
	List<IContrainte> contraintes=new ArrayList<>();
	
	public GrillePotentiel(GrillePlaces grille, Dictionnaire dicoComplet) {
		this.dico=dicoComplet;
		this.gr=grille;
		int i=0;
		this.motsPot=new ArrayList<>();
		for (Emplacement e : gr.getPlaces()) {
			Dictionnaire d=dico.copy();
			motsPot.add(i,d);
			int nb=motsPot.get(i).filtreLongueur(e.size());
			//on itere sur les cases pour voir si elles ont un contenue (elle n'est ni pleine ni vide)
			int j=0;
			for(Case c : e.getLettres()) {
				if((!c.isVide()) && (!c.isPleine())) { //s'il y a une lettre 
					nb=motsPot.get(i).filtreParLettre(c.getChar(), j);
				}
				j++;
			}
			i++;
		}
		int hori=gr.getNbHorizontal();
		int verti=gr.getNbVerticale();
		List<Emplacement> horizontale=new ArrayList<>();
		List<Emplacement> verticale=new ArrayList<>();
		int tmp=0;
		for(int a=0;a<hori;a++) {
			horizontale.add(gr.getPlaces().get(a));
			tmp=a;
		}
		int b=tmp+1;
		while (b<verti+hori)  {
			verticale.add(gr.getPlaces().get(b));
			b++;
		}
		//on a initialiser deux listes pour séparer les emplacements horizontaux et les emplacements verticaux
		int com=0;
		int offseth=0, offsetv=0;
		int caseh=0,casev=0;
		for (Emplacement h: horizontale) {
			offsetv=hori;
			for (Emplacement v: verticale ) {
				caseh=0;
				for(Case cha: h.getLettres()) {
					casev=0;
					for (Case chb:v.getLettres()) {
						if ((cha.getLig())==(chb.getLig()) && (cha.getCol())==(chb.getCol())) {
							if(cha.isVide() || chb.isVide()) {
								contraintes.add(new CroixContrainte(offseth,caseh,offsetv, casev));
								com++;
							}
						}
						casev++;
					}
					caseh++;
				}
				offsetv++;
			}
			offseth++;
		}
		for(IContrainte cont: contraintes) { //detection des contraintes
			cont.reduce(this);
		}
		boolean bo=this.propage();
	}
	public boolean isDead() { //renvoie vraie si  au moins un domaine est vide
		for ( Dictionnaire d: motsPot) {
			if (d.size()==0) {
				return true;
			}
		}
		return false;
		
	}
	
	public GrillePlaces getGrillePlaces(){
		return gr;
	}
	public List<IContrainte> getContraintes() {
		return this.contraintes;
	}
	
	public Dictionnaire getDico(){
		return dico;
	}
	
	public List<Dictionnaire> getMotsPot() {
		return motsPot;
	}
	public GrillePotentiel fixer(int m, String soluce) {
		GrillePlaces g=gr.fixer(m,soluce);
		return new GrillePotentiel(g,this.dico);
	}
	private boolean propage() {
		int motE=0;
		while (true) {
			for(IContrainte cont: contraintes) {
				motE+=cont.reduce(this);
			}
			if (this.isDead()) { 
				return false; 
				
			}
			if (motE==0) { return true; } 
			motE=0;
		}
		
	}
	
	public void setGrillePlaces(GrillePlaces g){
		this.gr=g;
	}
	
	
}
