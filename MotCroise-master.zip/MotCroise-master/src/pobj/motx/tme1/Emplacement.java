package pobj.motx.tme1;

import java.util.List;

public class Emplacement {

   private List<Case> lettres;

   public Emplacement(List<Case> list){
       lettres=list;
   }

   public String toString(){
	   String s=" ";
	   for(Case c:lettres){
		   s+=c.getChar();
	   }
	   return s;
   }
   
   
   public int size(){
	    return lettres.size();
   }
   
   public List<Case> getLettres(){
	   return lettres;
   }
   public boolean  hasCaseVide() {
	   for (Case c :this.lettres) {
		   if (c.isVide()) {
			   return true;
		   }
	   }
	   return false;
   }
   
   
   public void addEmplacement(Case c) {
	   lettres.add(c);
   }
   public String afficheCase1() {
	   String str="x="+lettres.get(0).getLig()+"et y="+lettres.get(0).getCol();
	   return str;
   }
}
