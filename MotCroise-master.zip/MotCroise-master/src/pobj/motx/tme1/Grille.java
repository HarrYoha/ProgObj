package pobj.motx.tme1;



public class Grille {
	private Case[][] m;
	private int hauteur,largeur;
	
	
	public Grille(int hauteur, int largeur) {
		this.hauteur = hauteur;
		this.largeur = largeur;
		this.m=new Case[this.hauteur][this.largeur];
		for(int i=0;i<this.hauteur;i++) {
			for(int j=0;j<this.largeur;j++) {
				m[i][j]=new Case(i,j,' ');
			}
		}
	}
	
	public Case getCase(int lig,int col) {
		return m[lig][col];
	}

	@Override
	public String toString() {
		return GrilleLoader.serialize(this,false);
	}
	public int nbLig() {
		return hauteur;
	}

	public int nbCol() {
		return largeur;
	}
	
	public Grille copy()    {
		Grille gr= new Grille(hauteur,largeur);
		for(int i=0;i<this.hauteur;i++) {
			for(int j=0;j<this.largeur;j++) {
				gr.m[i][j]=new Case(i,j,this.m[i][j].getChar());
			}
		}
		return gr;
	}
}
