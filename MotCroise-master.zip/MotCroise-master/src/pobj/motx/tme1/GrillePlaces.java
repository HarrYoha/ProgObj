package pobj.motx.tme1;

import java.util.ArrayList;
import java.util.List;

public class GrillePlaces {

	private List<Emplacement> places;

	private Grille grille;

	private int nbHori = 0;

	/**
	 * @param grille
	 */
	public GrillePlaces(Grille grille) {
		places = new ArrayList<>();
		this.grille = grille;
		for (int i = 0; i < grille.nbLig(); i++) {
			chercherPlaces(getLig(i));
		}
		int tmp = nbHori;

		for (int j = 0; j < grille.nbCol(); j++) {
			chercherPlaces(getCol(j));
		}
		nbHori = tmp;
	}

	/**
	 * @param cases
	 */
	private void chercherPlaces(List<Case> cases) {
		List<Case> l = new ArrayList<>();
		Emplacement e = new Emplacement(l);
		for (Case c : cases) {
			if ((c.isVide()) ||  !(c.isPleine()))  {
				e.addEmplacement(c);
			} else {
				if (c.isPleine()) {
					if (e.size() >= 2) {
						places.add(e);
						nbHori++;
						List<Case> be = new ArrayList<>();
						Emplacement ce = new Emplacement(be);
						e = ce;
					} else {
						List<Case> le = new ArrayList<>();
						Emplacement ne = new Emplacement(le);
						e = ne;
					}
				}else {
					e.addEmplacement(c);

				}
			}

		}
		if (e.size() >= 2) {
			places.add(e);
			nbHori++;
		}

	}

	/**
	 * @param lig
	 * @return
	 */
	private List<Case> getLig(int lig) { // prends une ligne et rends toutes les cases de la ligne dans une liste
		List<Case> list = new ArrayList<>();
		for (int i = 0; i < this.grille.nbCol(); i++) {
			list.add(grille.getCase(lig, i));
		}
		return list;
	}

	private List<Case> getCol(int col) {
		List<Case> list = new ArrayList<>();
		for (int i = 0; i < this.grille.nbLig(); i++) {
			list.add(grille.getCase(i, col));
		}
		return list;
	}

	public List<Emplacement> getPlaces() {
		return places;
	}

	
	public int getNbHorizontal() {
		return nbHori;
	}
	
	public int getNbVerticale() {
		return (places.size()-nbHori);
	}

	public String toString() {
		String hori = "Horizontal";
		System.out.println("Horizontal:");

		for (int i = 0; i < nbHori; i++) {
			for (Case c : places.get(i).getLettres()) {
				hori = hori + "(" + String.valueOf(c.getLig()) + "," + String.valueOf(c.getCol()) + ")/";
			}
		}
		return hori;
	}
	
	public GrillePlaces fixer(int m,String soluce) {
		Grille ne=this.grille.copy();
		Emplacement e=places.get(m);
		char[] chars = soluce.toCharArray();
		int i=0;
		for (Case c: e.getLettres()) {
			ne.getCase(c.getLig(),c.getCol()).setChar(chars[i]);
			System.out.println(chars[i]);
			ne.getCase(c.getLig(), c.getCol()).setChar(chars[i]);
			i++;
		}
		return new GrillePlaces(ne);
	}
	
	
}
