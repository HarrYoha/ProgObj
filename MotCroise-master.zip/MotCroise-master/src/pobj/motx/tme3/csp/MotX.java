package pobj.motx.tme3.csp;

import java.util.ArrayList;
import java.util.List;

import pobj.motx.tme1.Case;
import pobj.motx.tme1.Emplacement;
import pobj.motx.tme1.GrillePlaces;
import pobj.motx.tme2.GrillePotentiel;

public class MotX implements ICSP {

	List<IVariable> d;
	GrillePotentiel gp;
	
	public MotX(GrillePotentiel gp) {
		d = new ArrayList<>();
		this.gp=gp;
		creerDicoVariable();
	}

	@Override
	public List<IVariable> getVars() {
		return this.d;
	}										

	@Override
	public boolean isConsistent() {
		return !gp.isDead();
	}

	public void creerDicoVariable() {
		int i = 0;
		for (Emplacement e : gp.getGrillePlaces().getPlaces()) {
			if  (e.hasCaseVide()) {
				DicoVariable dv =new DicoVariable(i,gp);
				d.add(dv);
			}
			i++;
		}
	}

	@Override
	public ICSP assign(IVariable vi, String val) {
		if(! (vi instanceof  DicoVariable))
			return null;
		DicoVariable v=(DicoVariable) vi;
		GrillePotentiel gg=new GrillePotentiel(gp.getGrillePlaces(),gp.getDico());
		gg.setGrillePlaces(v.getGrillePotentiel().getGrillePlaces().fixer(v.getIndice(), val));
		GrillePotentiel gi= new GrillePotentiel(gg.getGrillePlaces(),gp.getDico() );
		return new MotX(gi);
	}

	public GrillePotentiel getGrillePotentiel(){
		return gp;
	}
}
