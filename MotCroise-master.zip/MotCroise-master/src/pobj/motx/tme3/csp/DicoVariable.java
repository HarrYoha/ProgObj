package pobj.motx.tme3.csp;

import java.util.ArrayList;
import java.util.List;

import pobj.motx.tme2.Dictionnaire;
import pobj.motx.tme2.GrillePotentiel;

public class DicoVariable implements IVariable {

	private int indice;
	private GrillePotentiel gr;
	
	
	public DicoVariable(int index, GrillePotentiel gp) {
		this.indice = index;
		this.gr = gp;
	}


	@Override
	public List<String> getDomain() {
		List<String> finale=new ArrayList<>();
		Dictionnaire d= gr.getMotsPot().get(indice);
		for(int i=0;i<d.size();i++) {
			finale.add(d.get(i));
		}
		return finale;
	}


	@Override
	public String toString() {
		String str="";
		for (String s: this.getDomain()) {
			str+= s+"\n";
		}
		/*StringBuilder sb=new StringBuilder();
		for (String s: getDomain()){
			sb.append(s);
		}
		System.out.println(+sb.toString());*/
		return str;
	}
	
	public GrillePotentiel getGrillePotentiel(){
		return gr;
	}
	
	public int getIndice(){
		return indice;
	}
	
	

}
