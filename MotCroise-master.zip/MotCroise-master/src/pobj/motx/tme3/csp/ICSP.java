package pobj.motx.tme3.csp;


import java.util.List;


public interface ICSP {
	List<IVariable> getVars(); //acceder aux variable du probleme 
	boolean isConsistent(); //tester si un probleme est encore satisfaisable 
	ICSP assign(IVariable vi, String val); //affecter une des variables du probleme
}
